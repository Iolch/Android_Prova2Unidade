package com.example.a2unidadeprova

class Task (var name: String, var description: String, var checked: Int, var id:Long=0L)