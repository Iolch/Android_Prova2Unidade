package com.example.a2unidadeprova

const val DATABASE_NAME = "dbproject"
const val DATABASE_VERSION = 1
const val TABLE_NAME = "tasks"
const val COLOUMN_ID = "_id"
const val COLOUMN_NAME = "_name"
const val COLOUMN_DESCRIPTION = "_description"
const val COLOUMN_CHECKED = "_checked"